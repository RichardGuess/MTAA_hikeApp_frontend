import { Slot, useNavigation } from 'expo-router';
import { View, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import { ParamListBase } from '@react-navigation/native';

type NavigationProp = DrawerNavigationProp<ParamListBase>;

export default function DrawerLayout() {
  const navigation = useNavigation<NavigationProp>();

  return (
    <View style={{ flex: 1 }}>
      <Pressable
        onPress={() => navigation.toggleDrawer()}
        style={styles.burger}
      >
        <Ionicons name="menu" size={24} color="black" />
      </Pressable>
      <Slot />
    </View>
  );
}

const styles = StyleSheet.create({
  burger: {
    position: 'absolute',
    top: 50,
    left: 16,
    zIndex: 999,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 6,
    elevation: 5,
  },
});
