import * as React from 'react';
import { View, Text } from "react-native";

export default function FriendsListScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Friends List</Text>
    </View>
  );
}
