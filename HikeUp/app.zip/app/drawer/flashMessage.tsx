import FlashMessage from "react-native-flash-message";

export default function App() {
  return (
    <>
      {/* Your app content */}
      <FlashMessage position="top" />
    </>
  );
}