import { Drawer } from "expo-router/drawer";
import FlashMessage from "react-native-flash-message";

export default function RootLayout() {
  return (
    <>
      <FlashMessage position="top" />
      <Drawer screenOptions={{ headerShown: false }} />
    </>
  );
}