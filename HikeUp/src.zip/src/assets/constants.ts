// export const LOCAL_IP = "http://147.175.162.24:5433";
// export const LOCAL_IP = "http://192.168.1.58:5433";
export const LOCAL_IP = "http://192.168.50.43:5433";
// export const LOCAL_IP = "http://172.20.10.2:5433";
export const GOOGLE_MAPS_API = "AIzaSyB3hQf1jpnDFgVdGsAISpFj21Yqp493qtE";