import { Redirect } from "expo-router";

export default function GoToMapTab() {
  return <Redirect href="./homeBar/map" />;
}